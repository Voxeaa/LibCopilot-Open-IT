import streamlit as st
import requests
import json
import math
import os

# --- NEW DATABASE IMPORTS ---
from sqlalchemy import create_engine, Column, Integer, String, Text, text
from sqlalchemy.orm import declarative_base, sessionmaker
from pgvector.sqlalchemy import Vector

# ==========================================
# DATABASE CONFIGURATION
# ==========================================
# Connect to your local PostgreSQL database
DATABASE_URL = "postgresql://postgres:ccms@localhost:5432/Library"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

class Document(Base):
    __tablename__ = "documents"
    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    embedding = Column(Vector(768)) # <--- REVERTED TO 768

# ==========================================
# PAGE CONFIGURATION
# ==========================================
st.set_page_config(page_title="MSEUF Library Copilot", page_icon="📚", layout="wide")

# ==========================================
# STRICT SYSTEM PROMPT DEFINITION
# ==========================================
SYSTEM_PROMPT = """
YOU ARE THE MSEUF LIBRARY ASSISTANT. YOU ARE STRICTLY CONFINED TO THE MSEUF LIBRARY.

RULE 1: GREETINGS AND CAPABILITIES
If the user says "Hi", "Hello", or asks "What can you do?": 
- DO NOT CALL ANY TOOLS. 
- Reply EXACTLY: "Hello! I am the MSEUF Library Assistant. I can help you with borrowing rules, facility sections, and calculating fines. How can I help you today?"

RULE 2: OFF-TOPIC REFUSAL
If the user asks about ANY non-library topic (e.g., history, essays, coding, trivia, World War 2):
- DO NOT CALL ANY TOOLS.
- Reply EXACTLY: "I am strictly an MSEUF Library Assistant. I cannot help with outside topics."

RULE 3: LIBRARY QUESTIONS
If the user asks about library rules, hours, sections, or policies:
- You MUST call the `search_library_policies` tool.
- Base your answer ONLY on the retrieved text. If not found, say "I do not have that information."

RULE 4: FINES
If the user asks about late fees:
- You MUST call the `calculate_fines` tool.
- If they do not specify 'circulation' or 'reserved', ask them first before calling the tool.
"""

# ==========================================
# SESSION STATE MANAGEMENT
# ==========================================
if "chats" not in st.session_state:
    st.session_state.chats = {
        "Chat 1": [{"role": "system", "content": SYSTEM_PROMPT}]
    }
if "current_chat" not in st.session_state:
    st.session_state.current_chat = "Chat 1"
if "chat_counter" not in st.session_state:
    st.session_state.chat_counter = 1

# ==========================================
# SIDEBAR: LOGO, CONTROLS & CHAT HISTORY
# ==========================================
with st.sidebar:
    # 1. Logo at the top of the sidebar
    if os.path.exists("logoLib.png"):
        st.image("logoLib.png", use_container_width=True)
    else:
        st.markdown("<h1 style='text-align: center;'>📚 MSEUF</h1>", unsafe_allow_html=True)
    
    st.divider()
    st.header("⚙️ Control Center")
    
    # 2. New Chat Button
    if st.button("➕ New Chat", use_container_width=True):
        st.session_state.chat_counter += 1
        new_chat_name = f"Chat {st.session_state.chat_counter}"
        st.session_state.chats[new_chat_name] = [{"role": "system", "content": SYSTEM_PROMPT}]
        st.session_state.current_chat = new_chat_name
        st.rerun()
        
    st.divider()
    
    # 3. Chat History with Delete Option
    st.markdown("### 🕒 Recent Chats")
    
    for chat_name in list(reversed(list(st.session_state.chats.keys()))):
        # Create columns: 4 parts for the button, 1 part for the delete icon
        col_btn, col_del = st.columns([4, 1])
        
        with col_btn:
            btn_type = "primary" if chat_name == st.session_state.current_chat else "secondary"
            if st.button(chat_name, use_container_width=True, type=btn_type, key=f"btn_{chat_name}"):
                st.session_state.current_chat = chat_name
                st.rerun()
                
        with col_del:
            if st.button("🗑️", key=f"del_{chat_name}"):
                # Delete the chat from memory
                del st.session_state.chats[chat_name]
                
                # If we just deleted the active chat, fallback safely
                if st.session_state.current_chat == chat_name:
                    if len(st.session_state.chats) > 0:
                        # Jump to the next available chat
                        st.session_state.current_chat = list(st.session_state.chats.keys())[-1]
                    else:
                        # If everything is deleted, create a brand new one
                        st.session_state.chat_counter += 1
                        new_name = f"Chat {st.session_state.chat_counter}"
                        st.session_state.chats[new_name] = [{"role": "system", "content": SYSTEM_PROMPT}]
                        st.session_state.current_chat = new_name
                st.rerun()
            
    st.divider()
    
    # Export current conversation
    active_chat_data = st.session_state.chats[st.session_state.current_chat]
    export_text = f"MSEUF Library Copilot Transcript ({st.session_state.current_chat})\n" + "="*40 + "\n\n"
    for msg in active_chat_data:
        if msg["role"] == "user":
            export_text += f"STUDENT: {msg['content']}\n"
        elif msg["role"] == "assistant":
            export_text += f"COPILOT: {msg['content']}\n\n"
            
    st.download_button(
        label="📥 Export Current Transcript",
        data=export_text,
        file_name=f"mseuf_library_{st.session_state.current_chat.replace(' ', '_').lower()}.txt",
        mime="text/plain",
        use_container_width=True
    )
    
    st.divider()
    st.caption("🟢 **System Status:** Online")

# ==========================================
# MAIN HEADER SECTION
# ==========================================
st.title("MSEUF Library Assistant 📚")
st.caption(f"Active Session: **{st.session_state.current_chat}** | Your intelligent, 24/7 companion for library services.")
st.divider()

# Replace your old get_embedding function with this:
def get_embedding(text):
    try:
        response = requests.post(
            "http://localhost:11434/api/embeddings", 
            json={"model": "nomic-embed-text", "prompt": text} # <--- REVERTED TO NOMIC
        )
        return response.json().get("embedding", [])
    except:
        return []

# ==========================================
# 2. MULTI-TOOL CONFIGURATION
# ==========================================
# Replace your old search_library_policies function with this:
def search_library_policies(params):
    query = params.get("search_query", "")
    query_embedding = get_embedding(query)
    
    if not query_embedding:
        return "System Notification: Could not generate embedding for query."

    with SessionLocal() as session:
        # Ask PostgreSQL to find the top 5 closest vectors
        result = session.execute(
            text("""
                SELECT content, 
                       1 - (embedding <=> CAST(:query_emb AS vector)) AS similarity
                FROM documents
                WHERE embedding IS NOT NULL
                ORDER BY embedding <=> CAST(:query_emb AS vector)
                LIMIT 5;
            """),
            {
                "query_emb": "[" + ",".join(map(str, query_embedding)) + "]"
            }
        )
        
        # Extract the text content from the database rows
        best_matches = [row.content for row in result]

    if not best_matches:
        return "System Notification: No library rules found in the database."

    # Combine the top 5 chunks into a string for the AI to read
    return "\n\n---\n\n".join(best_matches)

def calculate_fines(params):
    book_type = params.get("book_type", "").lower()
    try:
        days_late = int(params.get("days_late", 0))
    except ValueError:
        return "Error: days_late must be a valid number."
        
    if book_type == "circulation":
        total = days_late * 6
        return f"Calculation Result: {days_late} days late * ₱6.00 = ₱{total}.00 total fine."
    elif book_type == "reserved":
        total = days_late * 2
        return f"Calculation Result: {days_late} periods late * ₱2.00 = ₱{total}.00 total fine."
    else:
        return "Error: Book type must be 'circulation' or 'reserved'."

def process_tool(params, tool_name):
    if tool_name == "search_library_policies":
        return search_library_policies(params)
    elif tool_name == "calculate_fines":
        return calculate_fines(params)
    return f"Tool {tool_name} not found."

tools = [
    {
        "type": "function",
        "function": {
            "name": "search_library_policies",
            "description": "Searches the MSEUF manual. ONLY use this for explicit library questions (rules). DO NOT use this for greetings like 'Hi' or 'What can you do'.",
            "parameters": {
                "type": "object",
                "properties": {
                    "search_query": {
                        "type": "string",
                        "description": "A 2-3 word query to search the manual (e.g., 'borrowing rules', 'policies')."
                    }
                },
                "required": ["search_query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_fines",
            "description": "Calculates late fees based on days late.",
            "parameters": {
                "type": "object",
                "properties": {
                    "book_type": {
                        "type": "string", 
                        "enum": ["circulation", "reserved"],
                        "description": "MUST be 'circulation' or 'reserved'. Ask the user if they do not provide it."
                    },
                    "days_late": {
                        "type": "integer",
                        "description": "The number of days the book is overdue."
                    }
                },
                "required": ["book_type", "days_late"]
            }
        }
    }
]

# ==========================================
# 3. STREAMLIT CHAT UI 
# ==========================================
avatar_user = "👤"
avatar_assistant = "logoLib.png" if os.path.exists("logoLib.png") else "📚"

current_messages = st.session_state.chats[st.session_state.current_chat]

if len(current_messages) == 1:
    st.info("👋 **Welcome to the MSEUF Library Copilot!** I'm here to help you navigate library resources.")
    st.write("**Try asking me things like:**")
    colA, colB, colC = st.columns(3)
    with colA: st.markdown("🕒 *How can i renew a book online?*")
    with colB: st.markdown("💸 *Calculate a fine for a circulation book late by 3 days.*")
    with colC: st.markdown("📖 *What sections does the library have?*")
    st.write("")

for msg in current_messages:
    if msg["role"] == "user":
        with st.chat_message("user", avatar=avatar_user): st.markdown(msg["content"])
    elif msg["role"] == "assistant":
        with st.chat_message("assistant", avatar=avatar_assistant): st.markdown(msg["content"])
    elif msg["role"] == "tool":
        with st.chat_message("assistant", avatar="⚙️"):
            with st.expander(f"📄 Retrieved Knowledge Base Data ({msg.get('tool_name', 'System')})"):
                st.markdown(msg["content"])

prompt = st.chat_input("Ask me about policies, fines, or borrowing rules...")

def generate():
    payload = {
        "model": "llama3.1",
        "messages": st.session_state.chats[st.session_state.current_chat],
        "tools": tools,
        "stream": True
    }

    has_tool_calls = False
    complete_response = ""
    assistant_placeholder = None

    try:
        with requests.post("http://localhost:11434/api/chat", json=payload, stream=True) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line:
                    chunk = json.loads(line)
                    tool_calls = chunk.get("message", {}).get("tool_calls")
                    
                    if tool_calls:
                        has_tool_calls = True
                        for tool_call in tool_calls:
                            tool_call_id = tool_call["id"]
                            tool_call_name = tool_call["function"]["name"]
                            tool_call_args = tool_call["function"]["arguments"]                    

                            obj = {}
                            for key, value in tool_call_args.items():
                                if isinstance(value, str):
                                    try: obj[key] = json.loads(value)
                                    except json.JSONDecodeError: obj[key] = value
                                else: obj[key] = value

                            with st.chat_message("assistant", avatar="⚙️"):
                                with st.status(f"🔍 AI is executing `{tool_call_name}`...", expanded=True) as status:
                                    st.write(f"**Query Parameters:** `{obj}`")
                                    tool_response = process_tool(obj, tool_call_name)
                                    status.update(label=f"✅ Data Retrieved successfully", state="complete", expanded=False)

                            st.session_state.chats[st.session_state.current_chat].append({
                                "role": "tool", 
                                "content": tool_response, 
                                "tool_name": tool_call_name,
                                "tool_call_id": tool_call_id
                            })
                    elif chunk.get("message", {}).get("content"):
                        if not assistant_placeholder:
                            assistant_placeholder = st.chat_message("assistant", avatar=avatar_assistant).empty()
                        complete_response += chunk["message"]["content"]
                        assistant_placeholder.markdown(complete_response + "▌")

        if has_tool_calls:
            generate()
        elif complete_response:        
            assistant_placeholder.markdown(complete_response)
            st.session_state.chats[st.session_state.current_chat].append({"role": "assistant", "content": complete_response})
            
    except requests.exceptions.ConnectionError:
        st.error("🔌 Connection Error: Cannot connect to the local LLaMA engine. Please ensure Ollama is running on localhost:11434.")

if prompt:
    st.session_state.chats[st.session_state.current_chat].append({"role": "user", "content": prompt})
    with st.chat_message("user", avatar=avatar_user): 
        st.markdown(prompt)
    generate()
