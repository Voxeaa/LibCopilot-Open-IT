# Capstone Project Guide for Learners

## What You Are Building

For this capstone, your team will complete **one project** in **3 days total**:

- **Day 1 to Day 2:** build, test, and refine your project
- **Day 3:** present your work

Your team must choose **one of two tracks**:

- **Track 1: Data Analytics**
- **Track 2: GenAI App**

Both tracks must solve a **real use case** and stay realistic for a **2-day build window**.

---

## Choose One Track

### Track 1: Data Analytics

Choose this track if your team wants to work mainly with:

- real public datasets
- cleaning, analysis, and visualization
- dashboards, charts, and recommendations

### Track 2: GenAI App

Choose this track if your team wants to build a lightweight AI application using lessons from:

- embeddings and semantic similarity
- semantic search or retrieval workflows
- chat interfaces
- conversation memory
- streaming responses
- optional tool calling

Your GenAI project should still solve a real user problem, not just demonstrate a model with random prompts.

---

## Final Deliverables

All teams must submit or present:

- a clear project title
- a problem statement
- target users or stakeholders
- source links for data or documents used
- a clear explanation of the workflow
- at least 3 meaningful findings, observations, or insights
- at least 2 practical recommendations or next steps
- a final presentation deck

### Track 1: Data Analytics Deliverables

Your team must include:

- dataset links
- a cleaned working dataset or documented data preparation process
- charts, tables, dashboard, or app
- at least 3 clear data insights

### Track 2: GenAI App Deliverables

Your team must include:

- document or data source links
- ingestion or preparation process
- a **working lightweight app**, preferably **Streamlit**
- at least one meaningful **AI engineering capability**
- demo scenarios that show how the app is used
- limitations and next steps

For most teams, the recommended AI capabilities are:

- **semantic search** over a small set of curated documents or records
- **tool calling** API calls to external services or databases
- **agentic retrieval** that combines multiple sources or steps

Other lesson-aligned capabilities may include:

- chat over retrieved context
- conversation memory
- streaming replies
- optional tool calling

---

## Capstone Rules

Your project must:

- be a **team project**
- solve a **real use case**
- be realistic to complete in **2 build days**
- use materials that your team can access immediately
- end with a clear presentation on Day 3

### Track 1: Data Analytics Rules

Your project must:

- use **real public data**
- include analysis and interpretation
- produce visuals, dashboard elements, or an app

### Track 2: GenAI App Rules

Your project must:

- include a **working runnable app**
- use a small, curated set of documents, records, or structured inputs
- include at least one meaningful retrieval or AI workflow
- be explainable by the team during the presentation

Avoid GenAI projects that depend on:

- large-scale web scraping
- very large document collections
- complex agent systems
- heavy fine-tuning
- advanced infrastructure not covered in class

Use tools already covered in the bootcamp whenever possible.

---

## Recommended Tools

Use the simplest toolset that helps your team finish strongly.

### Track 1: Data Analytics

- **Excel** for quick inspection and validation
- **SQL** for structured querying
- **Power BI** for dashboards
- **Python** with Pandas, Matplotlib, Seaborn, Plotly, or Streamlit

### Track 2: GenAI App

- **Python**
- **Streamlit**
- embeddings workflows from **Week 3 - Day 3**
- chat app patterns from **Week 3 - Day 4**
- Ollama or another model workflow already discussed in class

---

For most teams, the safest project pattern is:

1. prepare a small set of documents or records
2. create embeddings or another retrieval-ready structure
3. accept a user query
4. retrieve relevant context
5. display the result in a lightweight app

Optional enrichment:

- add a chat interface
- add conversation memory
- add streaming output
- add tool calling only if it clearly improves the use case

---

## How to Choose a Good Topic

Choose a topic that:

- matters to a real stakeholder or user
- has accessible data or documents
- can be finished within 2 build days
- leads to a clear story or demo
- can support practical recommendations

Ask these questions before finalizing your topic:

1. What problem are we solving?
2. Who is the user or stakeholder?
3. What action or decision could this support?
4. Can we build and explain this clearly in 2 days?

---

## Recommended Project Ideas

These are suggested directions. You may propose a different topic if the scope is realistic.

### Track 1: Data Analytics Ideas

#### 1. Regional Development Dashboard

Possible question:

How do inflation, employment, poverty, and regional economic output differ across Philippine regions?

#### 2. Labor Market and Unemployment Trends

Possible question:

How have employment, unemployment, and labor force participation changed over time?

#### 3. Public Health or Education Trend Analysis

Possible question:

What changes over time can be observed in selected health or education indicators, and what might they imply?

### Track 2: GenAI App Ideas

#### 1. FAQ or Policy Assistant

Build a small assistant that answers questions from a curated set of policy files, manuals, or guidelines.

Possible users:

- HR staff
- students
- new employees
- internal support teams

#### 2. Semantic Search for Reports or Articles

Build a search app that helps users find the most relevant sections from reports, articles, or course materials.

Possible users:

- researchers
- students
- analysts

#### 3. Stakeholder Copilot for Dataset + Documents

Build an app that helps a user explore a small dataset together with supporting text such as project notes, documentation, or summaries.

Possible users:

- project managers
- operations staff
- analysts

#### 4. Public Information Retrieval Assistant

Build an app that answers questions using a small set of public documents from a government, school, NGO, or service provider.

Possible users:

- citizens
- applicants
- community members

#### 5. Simple Support or Research Assistant

Build a lightweight chat app with retrieval and optional tool calling for a narrow, well-defined domain.

Possible users:

- help desk teams
- student researchers
- internal operations users

---

## Verified Public Dataset Sources for Track 1

If you choose the Data Analytics track, these are strong starting points:

- [PSA OpenSTAT](https://openstat.psa.gov.ph/)
- [BSP Online Statistical Database](https://www.bsp.gov.ph/PXWeb2007/dialog/statfile1.asp)
- [World Bank Open Data](https://data.worldbank.org/indicator/Home-Page)
- [WHO Data](https://data.who.int/)
- [ILOSTAT Data Portal](https://ilostat.ilo.org/data/)
- [UNESCO UIS Data Browser](https://databrowser.uis.unesco.org/)
- [FAOSTAT](https://www.fao.org/faostat/en/#data)

Start with one main source first. Add more only if they clearly improve the project.

---

## Suggested Document Sources for Track 2

If you choose the GenAI App track, prefer small, curated, easy-to-explain sources such as:

- school or bootcamp materials
- internal policy documents
- FAQ pages copied into text files
- short reports or summaries
- small public information documents
- structured records with short text descriptions

Prefer a smaller document set that works well over a larger document set that your team cannot finish cleaning or testing.

---

## Required Structure of Your Project

### 1. Problem Statement

Clearly explain:

- what problem you are solving
- who the user or stakeholder is
- why the problem matters
- what decision, task, or workflow your project supports

### 2. Source Documentation

Document:

- source names
- direct links
- covered files, datasets, or records
- time period covered, if relevant
- preparation or cleaning steps
- missing data, limits, or quality issues

### 3. Build or Analysis Process

#### Track 1: Data Analytics

Include:

- data inspection
- cleaning and validation
- descriptive statistics
- at least 3 meaningful visualizations
- at least 3 written insights

Optional depth:

- correlation
- regression
- forecasting
- segmentation

#### Track 2: GenAI App

Include:

- source collection and preparation
- app workflow
- retrieval or semantic search process
- app testing with sample prompts or use cases
- at least 3 observations about what worked, failed, or needs improvement

Optional depth:

- chat memory
- streaming
- tool calling

### 4. Final Presentation

Your presentation should include:

1. title and team members
2. problem and audience
3. sources used
4. preparation or build process
5. analysis workflow or app workflow
6. charts or demo
7. insights or observations
8. recommendations
9. limitations
10. next steps

---

## Suggested Team Roles

You may divide the work using roles like these:

- **Researcher / Source Owner**: finds and documents datasets or documents
- **Data Cleaner / Preparation Lead**: prepares data or source content
- **Analyst / AI Workflow Lead**: handles analysis or retrieval logic
- **App / Visualization Lead**: builds the UI, visuals, or demo flow

Note: one team may handle more than one role.

---

## 3-Day Work Plan

### Day 1: Finalize Topic and Build the First Working Version

Your goals:

- choose your track
- define the problem and target user
- confirm your data or document sources
- prepare the first usable inputs
- build the first working version

By the end of Day 1, you should have:

- a finalized topic
- a clear problem statement
- source links
- a usable dataset or document set
- a first working analysis flow or app prototype

### Day 2: Improve, Test, and Prepare the Presentation

Your goals:

- improve the analysis or app workflow
- test your outputs or demo scenarios
- identify findings, observations, and limits
- finalize visuals or app screens
- build the presentation deck

By the end of Day 2, you should have:

- a polished analysis or runnable app
- clear findings or observations
- a complete presentation draft
- assigned speaking roles

### Day 3: Present

Your goals:

- present clearly
- explain your workflow
- demonstrate the app or explain the analysis
- defend your findings
- answer questions

---

## What Strong Findings Look Like

A strong finding does more than describe what is visible.

Weak finding:

`The app returns matching answers.`

Stronger finding:

`The semantic search workflow performs well when the source documents are small and specific, but vague queries produce weaker results, which suggests that clearer chunking or more focused source material would improve reliability.`

Try to explain:

- what happened
- why it matters
- what action or improvement should follow

---

## Common Mistakes to Avoid

- choosing a topic that is too broad
- using too many data or document sources
- spending too much time collecting materials
- building a complex app that the team cannot explain
- relying on advanced AI features before the basics work
- presenting a demo without testing realistic user questions
- showing outputs without interpretation

---

## If Your Team Is Undecided

Choose one of these safe starting options.

### Safe Default for Track 1

**Project title:** Regional Development Dashboard for the Philippines

**Core question:** How do inflation, employment, poverty, and regional economic output differ across regions and over time?

**Recommended source:** [PSA OpenSTAT](https://openstat.psa.gov.ph/)

### Safe Default for Track 2

**Project title:** Semantic Search Assistant for Course or Policy Documents

**Core question:** How can a user quickly find the most relevant answer or section from a small set of curated documents?

**Recommended approach:** build a lightweight Streamlit app with embeddings-based retrieval and a simple chat or search interface

These are strong defaults because they are:

- realistic
- explainable
- aligned with class lessons
- possible to finish within 2 build days

---

## Final Checklist

Before presentation day, confirm that your team has:

- chosen one clear track
- defined a real problem and target user
- kept the scope realistic
- saved all source links
- documented preparation steps
- built a working analysis flow or runnable app
- prepared at least 3 findings, observations, or insights
- prepared recommendations or next steps
- finalized the slide deck
- assigned speaking roles
- practiced the presentation

